package com.rizky.lockerrizky;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText etEmail, etPassword;
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        preferences = getSharedPreferences(
                "LockerRizkyPrefs", MODE_PRIVATE);

        if (preferences.getBoolean("loggedIn", false)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_login);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);

        Button btnLogin = findViewById(R.id.btnLogin);
        TextView tvRegister = findViewById(R.id.tvRegister);

        btnLogin.setOnClickListener(v -> login());

        tvRegister.setOnClickListener(v -> {
            startActivity(
                    new Intent(this, RegisterActivity.class)
            );
        });
    }

    private void login() {

        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        String savedEmail = preferences.getString("email", "");
        String savedPassword = preferences.getString("password", "");

        if (email.isEmpty() || password.isEmpty()) {

            Toast.makeText(this,
                    "Email dan password wajib diisi",
                    Toast.LENGTH_SHORT).show();

        } else if (email.equals(savedEmail)
                && password.equals(savedPassword)
                && !savedEmail.isEmpty()) {

            preferences.edit()
                    .putBoolean("loggedIn", true)
                    .apply();

            Toast.makeText(this,
                    "Login berhasil",
                    Toast.LENGTH_SHORT).show();

            startActivity(
                    new Intent(this, MainActivity.class)
            );

            finish();

        } else {

            Toast.makeText(this,
                    "Email atau password salah",
                    Toast.LENGTH_SHORT).show();
        }
    }
}