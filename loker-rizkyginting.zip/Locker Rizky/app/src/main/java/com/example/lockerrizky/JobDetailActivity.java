package com.rizky.lockerrizky;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class JobDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_job_detail);

        TextView title = findViewById(R.id.tvDetailTitle);
        TextView company = findViewById(R.id.tvDetailCompany);
        TextView location = findViewById(R.id.tvDetailLocation);
        TextView salary = findViewById(R.id.tvDetailSalary);
        TextView description = findViewById(R.id.tvDetailDescription);

        Button btnBack = findViewById(R.id.btnBack);

        title.setText(getIntent().getStringExtra("title"));

        company.setText(
                getIntent().getStringExtra("company")
        );

        location.setText(
                "Lokasi: " + getIntent().getStringExtra("location")
        );

        salary.setText(
                "Gaji: " + getIntent().getStringExtra("salary")
        );

        description.setText(
                getIntent().getStringExtra("description")
        );

        btnBack.setOnClickListener(v -> finish());
    }
}