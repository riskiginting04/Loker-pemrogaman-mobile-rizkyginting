package com.rizky.lockerrizky;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        EditText etName = findViewById(R.id.etName);
        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);

        Button btnRegister = findViewById(R.id.btnRegister);
        TextView tvLogin = findViewById(R.id.tvLogin);

        btnRegister.setOnClickListener(v -> {

            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty()
                    || password.isEmpty()) {

                Toast.makeText(this,
                        "Semua kolom harus diisi",
                        Toast.LENGTH_SHORT).show();

            } else if (!android.util.Patterns.EMAIL_ADDRESS
                    .matcher(email).matches()) {

                Toast.makeText(this,
                        "Format email tidak valid",
                        Toast.LENGTH_SHORT).show();

            } else if (password.length() < 6) {

                Toast.makeText(this,
                        "Password minimal 6 karakter",
                        Toast.LENGTH_SHORT).show();

            } else {

                SharedPreferences prefs =
                        getSharedPreferences(
                                "LockerRizkyPrefs",
                                MODE_PRIVATE
                        );

                prefs.edit()
                        .putString("name", name)
                        .putString("email", email)
                        .putString("password", password)
                        .putBoolean("loggedIn", false)
                        .apply();

                Toast.makeText(this,
                        "Registrasi berhasil. Silakan login.",
                        Toast.LENGTH_LONG).show();

                finish();
            }
        });

        tvLogin.setOnClickListener(v -> finish());
    }
}