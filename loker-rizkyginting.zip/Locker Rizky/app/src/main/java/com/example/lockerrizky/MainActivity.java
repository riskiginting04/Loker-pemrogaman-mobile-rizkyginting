package com.rizky.lockerrizky;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences prefs =
                getSharedPreferences(
                        "LockerRizkyPrefs", MODE_PRIVATE);

        TextView tvWelcome = findViewById(R.id.tvWelcome);
        Button btnLogout = findViewById(R.id.btnLogout);
        RecyclerView recyclerJobs = findViewById(R.id.recyclerJobs);

        tvWelcome.setText(
                "Halo, " + prefs.getString("name", "Pengguna") + "!"
        );

        recyclerJobs.setLayoutManager(
                new LinearLayoutManager(this)
        );

        recyclerJobs.setAdapter(
                new JobAdapter(getSampleJobs(), job -> {

                    Intent intent = new Intent(
                            MainActivity.this,
                            JobDetailActivity.class
                    );

                    intent.putExtra("title", job.getTitle());
                    intent.putExtra("company", job.getCompany());
                    intent.putExtra("location", job.getLocation());
                    intent.putExtra("salary", job.getSalary());
                    intent.putExtra("description", job.getDescription());

                    startActivity(intent);
                })
        );

        btnLogout.setOnClickListener(v -> {

            prefs.edit()
                    .putBoolean("loggedIn", false)
                    .apply();

            startActivity(
                    new Intent(this, LoginActivity.class)
            );

            finish();
        });
    }

    private List<Job> getSampleJobs() {

        List<Job> jobs = new ArrayList<>();

        jobs.add(new Job(
                "Android Developer",
                "PT Teknologi Nusantara",
                "Medan",
                "Rp5.000.000 - Rp7.000.000",
                "Mengembangkan dan memelihara aplikasi Android. " +
                        "Kandidat diharapkan memahami Java, XML, dan API."
        ));

        jobs.add(new Job(
                "Admin Kantor",
                "CV Maju Bersama",
                "Pematangsiantar",
                "Rp3.000.000 - Rp4.000.000",
                "Mengelola dokumen, memasukkan data, " +
                        "dan membuat laporan administrasi."
        ));

        jobs.add(new Job(
                "UI/UX Designer",
                "Kreasi Digital Indonesia",
                "Medan",
                "Rp4.500.000 - Rp6.500.000",
                "Membuat rancangan antarmuka aplikasi " +
                        "dan menyusun wireframe."
        ));

        jobs.add(new Job(
                "Data Entry",
                "PT Solusi Data",
                "Binjai",
                "Rp3.000.000 - Rp4.000.000",
                "Memasukkan dan memeriksa data " +
                        "serta menyusun laporan."
        ));

        jobs.add(new Job(
                "Customer Service",
                "Sentra Layanan",
                "Medan",
                "Rp3.500.000 - Rp5.000.000",
                "Melayani pertanyaan pelanggan " +
                        "dan membantu menyelesaikan keluhan."
        ));

        return jobs;
    }
}